package parkinglotmanager;

import vehicle.Car;
import org.junit.Before;
import org.junit.Test;
import static org.junit.Assert.*;

public class TestSlotNumForReg {
    private ParkingLotManager parkingLotManager = new ParkingLotManager();

    @Before
    public void setup(){
        parkingLotManager.createParkingLot(6);
        parkingLotManager.park(new Car("KA-01-HH-1234", "white"));
        parkingLotManager.park(new Car("KA-01-HH-9999", "blue"));
    }

    @Test
    public void testSlotNumForReg(){
        assertEquals("1", parkingLotManager.getSlotNumForReg("KA-01-HH-1234"));
    }

    @Test
    public void testSlotNumForRegWhenNotPresent(){
        assertEquals("Not found", parkingLotManager.getSlotNumForReg("KA-01-HJ-1274"));
    }
}
