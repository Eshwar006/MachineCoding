package parkinglotmanager;

import vehicle.Car;
import org.junit.Before;
import org.junit.Test;
import static org.junit.Assert.*;

public class TestSlotWithColor {
    private ParkingLotManager parkingLotManager = new ParkingLotManager();

    @Before
    public void setup(){
        parkingLotManager.createParkingLot(6);
        parkingLotManager.park(new Car("KA-01-HH-1234", "white"));
        parkingLotManager.park(new Car("KA-01-HH-9999", "white"));
        parkingLotManager.park(new Car("KA-01-P-333", "white"));
        parkingLotManager.park(new Car("KA-02-B-1234", "red"));
        parkingLotManager.park(new Car("KA-01-PQ-9999", "blue"));
        parkingLotManager.park(new Car("KA-21-C-123", "red"));
    }

    @Test
    public void testGetSlotWithColor(){
        assertEquals("1, 2, 3", parkingLotManager.getSlotWithColor("white"));
    }

    @Test
    public void testGetSlotWithColorForEmpty(){
        assertEquals("Not found", parkingLotManager.getSlotWithColor("yellow"));
    }

    @Test
    public void testGetSlotWithColorForSingle(){
        assertEquals("5", parkingLotManager.getSlotWithColor("blue"));
    }
}
