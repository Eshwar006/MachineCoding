package command;

import org.junit.Test;
import parkinglotmanager.ParkingLotManager;
import vehicle.Car;

import static org.junit.Assert.*;

public class TestCommandLeave {

    @Test(expected = IllegalArgumentException.class)
    public void testCommandLeaveArgumentException(){
        ParkingLotManager parkingLotManager = new ParkingLotManager();
        String[] arguments = {"leave", "2", "ok"};
        CommandLeave commandLeave = new CommandLeave(parkingLotManager, arguments);
    }

    @Test
    public void testCommandLeaveInvalidSlot(){
        ParkingLotManager parkingLotManager = new ParkingLotManager();
        parkingLotManager.createParkingLot(2);
        String[] arguments = {"leave", "-1"};
        CommandLeave commandLeave = new CommandLeave(parkingLotManager, arguments);
        assertEquals("Not Supported", commandLeave.execute());
    }

    @Test
    public void testCommandLeave(){
        ParkingLotManager parkingLotManager = new ParkingLotManager();
        parkingLotManager.createParkingLot(3);
        parkingLotManager.park(new Car("KA-02-B-5543", "red"));
        String[] arguments = {"leave", "1"};
        CommandLeave commandLeave = new CommandLeave(parkingLotManager, arguments);
        assertEquals("Slot number 1 is free", commandLeave.execute());
    }

}
