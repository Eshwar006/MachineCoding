package parkingslot;

import vehicle.Car;

public class ParkingSlot {
    private int parkingSlotId;
    private boolean isEmpty;
    private Car vehicle;

    public ParkingSlot(int id){
        this.parkingSlotId = id;
        this.isEmpty = true;
        this.vehicle = null;
    }

    public void parkVehicle(Car vehicle){
        if(this.isEmpty) {
            this.vehicle = vehicle;
            this.isEmpty = false;
        }
    }

    public void unParkVehicle(){
        this.vehicle = null;
        this.isEmpty = true;
    }

    public int getParkingSlotId() {
        return parkingSlotId;
    }

    public boolean isEmpty() {
        return isEmpty;
    }

    public Car getVehicleParked() {
        return vehicle;
    }
}
