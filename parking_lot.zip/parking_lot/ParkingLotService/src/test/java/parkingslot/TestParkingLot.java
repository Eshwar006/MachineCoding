package parkingslot;

import vehicle.Car;
import org.junit.*;
import static org.junit.Assert.*;

public class TestParkingLot {

    @Test
    public void testParkingLotCreation(){
        int slotId = 1;
        ParkingSlot parkingLot = new ParkingSlot(slotId);

        assertEquals(slotId, parkingLot.getParkingSlotId());
        assertTrue(parkingLot.isEmpty());
        assertNull(parkingLot.getVehicleParked());
    }

    @Test
    public void testParkVehicleTest(){
        int slotId = 1;
        String vehicleNumber = "KA 02 B 4523";
        Car car = new Car(vehicleNumber, "red");
        ParkingSlot parkingLot = new ParkingSlot(slotId);
        parkingLot.parkVehicle(car);

        assertNotNull(parkingLot.getVehicleParked());
        assertEquals(car, parkingLot.getVehicleParked());
        assertFalse(parkingLot.isEmpty());
    }

    @Test
    public void testParkVehicle(){
        int slotId = 1;
        String vehicleNumber1 = "KA 02 B 4523";
        String vehicleNumber2 = "KA 03 B 1234";
        String color1 = "red";
        String color2 = "blue";
        Car car1 = new Car(vehicleNumber1, color1);
        Car car2 = new Car(vehicleNumber2, color2);
        ParkingSlot parkingLot = new ParkingSlot(slotId);
        parkingLot.parkVehicle(car1);
        parkingLot.parkVehicle(car2);

        assertNotNull(parkingLot.getVehicleParked());
        assertEquals(car1, parkingLot.getVehicleParked());
        assertFalse(parkingLot.isEmpty());
    }

    @Test
    public void testUnparkvehicleTest(){
        int slotId = 1;
        String vehicleNumber = "KA 02 B 4523";
        String color = "red";
        ParkingSlot parkingLot = new ParkingSlot(slotId);
        parkingLot.parkVehicle(new Car(vehicleNumber, color));
        parkingLot.unParkVehicle();

        assertNull(parkingLot.getVehicleParked());
        assertTrue(parkingLot.isEmpty());
    }
}
