package parkinglotmanager;

import org.junit.Test;
import static org.junit.Assert.*;

public class TestCreateParkingLot {

    @Test
    public void testCreateEmptyParkingLot(){
        ParkingLotManager parkingLotManager = new ParkingLotManager();
        assertEquals(0, parkingLotManager.getParkingLotSize());
    }

    @Test
    public void testCreateParkingLot(){
        ParkingLotManager parkingLotManager = new ParkingLotManager();
        int numberOfSlots = 10;
        assertTrue(parkingLotManager.createParkingLot(numberOfSlots));
        assertEquals(numberOfSlots, parkingLotManager.getParkingLotSize());
    }

    @Test
    public void testCreateDuplicateLots(){
        ParkingLotManager parkingLotManager = new ParkingLotManager();
        parkingLotManager.createParkingLot(5);
        int numberOfSlots = 6;
        assertFalse(parkingLotManager.createParkingLot(numberOfSlots));
    }
}
