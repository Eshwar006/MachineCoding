package command;

import org.junit.Test;
import parkinglotmanager.ParkingLotManager;

import static org.junit.Assert.*;

public class TestCommandCreateLot {

    @Test(expected = IllegalArgumentException.class)
    public void testCommandCreateLotArgumentException(){
        ParkingLotManager parkingLotManager = new ParkingLotManager();
        String[] arguments = {"create_parking_lot", "6", "ok"};
        CommandCreateLot commandCreateLot = new CommandCreateLot(parkingLotManager, arguments);
    }

    @Test(expected = IllegalArgumentException.class)
    public void testCommandCreateLotInvalidSlot(){
        ParkingLotManager parkingLotManager = new ParkingLotManager();
        String[] arguments = {"create_parking_lot", "-1"};
        CommandCreateLot commandCreateLot = new CommandCreateLot(parkingLotManager, arguments);
    }

    @Test
    public void testCommandCreateLot(){
        ParkingLotManager parkingLotManager = new ParkingLotManager();
        String[] arguments = {"create_parking_lot", "6"};
        CommandCreateLot commandCreateLot = new CommandCreateLot(parkingLotManager, arguments);
        assertEquals( "Created a parking lot with 6 slots" , commandCreateLot.execute());
    }

    @Test
    public void testCommandCreateLotWhenLotExisting(){
        ParkingLotManager parkingLotManager = new ParkingLotManager();
        parkingLotManager.createParkingLot(6);
        String[] arguments = {"create_parking_lot", "6"};
        CommandCreateLot commandCreateLot = new CommandCreateLot(parkingLotManager, arguments);
        assertEquals( "Parking lot already Exists" , commandCreateLot.execute());
    }
}
