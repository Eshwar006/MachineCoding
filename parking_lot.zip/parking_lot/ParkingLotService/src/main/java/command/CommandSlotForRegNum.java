package command;

import parkinglotmanager.ParkingLotManager;

public class CommandSlotForRegNum implements Command{
    private  ParkingLotManager parkingLotManager;
    private String regNum;

    public CommandSlotForRegNum(ParkingLotManager parkingLotManager, String[] args){
        if (args.length != 2) throw new IllegalArgumentException("SlotNumForColorCommand");
        this.parkingLotManager = parkingLotManager;
        this.regNum = args[1];
    }

    @Override
    public String execute() {
        return parkingLotManager.getSlotNumForReg(regNum);
    }
}
