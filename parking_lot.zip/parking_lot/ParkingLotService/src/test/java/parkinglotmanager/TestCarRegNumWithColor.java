package parkinglotmanager;

import vehicle.Car;
import org.junit.Before;
import org.junit.Test;
import static org.junit.Assert.*;

public class TestCarRegNumWithColor {
    private ParkingLotManager parkingLotManager = new ParkingLotManager();

    @Before
    public void before(){
        parkingLotManager.createParkingLot(6);
        parkingLotManager.park(new Car("KA-01-HH-1234", "white"));
        parkingLotManager.park(new Car("KA-01-HH-9999", "white"));
        parkingLotManager.park(new Car("KA-01-P-333", "white"));
        parkingLotManager.park(new Car("KA-02-B-1234", "red"));
        parkingLotManager.park(new Car("KA-01-PQ-9999", "blue"));
        parkingLotManager.park(new Car("KA-21-C-123", "red"));
    }

    @Test
    public void testGetCarRegNumWithColor(){
        assertEquals("KA-01-HH-1234, KA-01-HH-9999, KA-01-P-333", parkingLotManager.getCarRegNumWithColor("white"));
    }

    @Test
    public void testGetCarRegNumWithColorForEmpty(){
        assertEquals("Not found", parkingLotManager.getCarRegNumWithColor("yellow"));
    }

    @Test
    public void testGetCarRegWithNumForSingle(){
        assertEquals("KA-01-PQ-9999", parkingLotManager.getCarRegNumWithColor("blue"));
    }
}
