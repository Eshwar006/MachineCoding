package command;

import parkinglotmanager.ParkingLotManager;

public class CommandCreateLot implements Command {

    private ParkingLotManager parkingLotManager;
    private int slotSize;

    public CommandCreateLot(ParkingLotManager parkingLotManager, String args[]){
        if(args.length != 2) throw new IllegalArgumentException("Create Lot");
        this.slotSize = Integer.valueOf(args[1]);
        if(this.slotSize < 1) throw new IllegalArgumentException("Invalid slot size");
        this.parkingLotManager = parkingLotManager;
    }

    @Override
    public String execute() {
        boolean createLot = parkingLotManager.createParkingLot(this.slotSize);
        if(createLot)
            return "Created a parking lot with " + this.slotSize + " slots";
        else
            return "Parking lot already Exists";
    }
}
