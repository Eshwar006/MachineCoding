package command;

import parkinglotmanager.ParkingLotManager;

public class CommandStatus implements Command{
    private  ParkingLotManager parkingLotManager;
    private static String printFormat = "%-12s%-19s%s";
    private static String[] header = {"Slot No.", "Registration No", "Colour"};

    public CommandStatus(ParkingLotManager parkingLotManager, String[] args){
        if(args.length != 1) throw  new IllegalArgumentException("StatusCommand");
        this.parkingLotManager = parkingLotManager;
    }

    @Override
    public String execute() {
        return parkingLotManager.getStatus(printFormat, header);
    }
}
