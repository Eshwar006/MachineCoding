package command;

import parkinglotmanager.ParkingLotManager;
import vehicle.Car;

public class CommandPark implements Command {

    private ParkingLotManager parkingLotManager;
    private Car car;
    private int parkedAt = -1;

    public CommandPark(ParkingLotManager parkingLotManager, String[] args){
        if(args.length != 3) throw new IllegalArgumentException("Park");
        this.parkingLotManager = parkingLotManager;
        this.car = new Car(args[1], args[2]);
    }

    @Override
    public String execute() {
        parkedAt = parkingLotManager.park(car);
        if(parkedAt == -1){
            return "Sorry, parking lot is full";
        } else {
            return "Allocated slot number: " + (parkedAt + 1);
        }
    }
}
