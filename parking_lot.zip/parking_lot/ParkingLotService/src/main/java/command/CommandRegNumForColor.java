package command;

import parkinglotmanager.ParkingLotManager;

public class CommandRegNumForColor implements Command {
    private ParkingLotManager parkingLotManager;
    private String color;

    public CommandRegNumForColor(ParkingLotManager parkingLotManager, String[] args){
        if (args.length != 2) throw new IllegalArgumentException("RegNumForColorCommand");
        this.parkingLotManager = parkingLotManager;
        this.color = args[1];
    }


    @Override
    public String execute() {
        return parkingLotManager.getCarRegNumWithColor(this.color);
    }
}
