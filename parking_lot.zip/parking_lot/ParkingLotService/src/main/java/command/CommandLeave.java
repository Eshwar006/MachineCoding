package command;

import parkinglotmanager.ParkingLotManager;

public class CommandLeave implements Command {

    private ParkingLotManager parkingLotManager;
    private int slot;

    public CommandLeave(ParkingLotManager parkingLotManager, String[] args){
        if (args.length != 2) throw new IllegalArgumentException("Leave");
        this.slot = Integer.valueOf(args[1]);
        this.parkingLotManager = parkingLotManager;
    }

    @Override
    public String execute() {
        if(slot < 1 || slot > parkingLotManager.getParkingLotSize())
            return "Not Supported";
        parkingLotManager.leave(slot);
        return "Slot number " + slot + " is free";
    }
}
