package vehicle;

import org.junit.*;
import static org.junit.Assert.*;

public class TestCar {

    @Test
    public void testCarObjectCreation(){
        String testRegistrationNumber = "KA 02 B 1234";
        String testColor = "red";
        Car car = new Car(testRegistrationNumber, testColor);
        assertEquals(testRegistrationNumber, car.getRegistrationNumber());
        assertEquals(testColor, car.getColor());
    }

}
