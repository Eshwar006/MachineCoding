package parkinglotmanager;

import parkingslot.ParkingSlot;
import vehicle.Car;

import java.util.ArrayList;
import java.util.stream.IntStream;

public class ParkingLotManager {
    private ArrayList<ParkingSlot> parkingLot = new ArrayList<ParkingSlot>();
    private static String notFound = "Not found";

    public boolean createParkingLot(int numberOfSlots){
        if(getParkingLotSize() != 0){
            return false;
        }
        for(int i=0; i<numberOfSlots; i++){
            this.parkingLot.add(new ParkingSlot(i));
        }
        return true;
    }

    public int getParkingLotSize(){
        return this.parkingLot.size();
    }

    private int getBestSlotAvailable(){
        for(ParkingSlot parkingLot: parkingLot){
            if(parkingLot.isEmpty())
                return parkingLot.getParkingSlotId();
        }
        return -1;
    }

    public int park(Car car){
        int bestSlot = getBestSlotAvailable();
        if(bestSlot >= 0){
            parkingLot.get(bestSlot).parkVehicle(car);
        }
        return bestSlot;
    }

    public boolean leave(int slot){
        if(parkingLot.get(slot-1).isEmpty()) return false;
        parkingLot.get(slot-1).unParkVehicle();
        return true;
    }

    public String getCarRegNumWithColor(String color){
        if(this.getParkingLotSize() == 0) return notFound;
        return this.parkingLot.stream()
                .map(slot -> (!slot.isEmpty() && color.equals(slot.getVehicleParked().getColor()))
                        ? slot.getVehicleParked().getRegistrationNumber(): "")
                .filter(s -> !s.equals(""))
                .reduce((accumulator, s) -> accumulator + ", " + s)
                .orElse(notFound);
    }

    public String getSlotWithColor(String color){
        int size = this.getParkingLotSize();
        if(size == 0 ) return notFound;
        return IntStream.range(0, getParkingLotSize())
                .filter(index -> !this.parkingLot.get(index).isEmpty() && color.equals(this.parkingLot.get(index).getVehicleParked().getColor()))
                .map(i -> i+1)
                .mapToObj(String::valueOf)
                .reduce((accumulator, x) -> accumulator + ", " + x)
                .orElse(notFound);
    }

    public String getSlotNumForReg(String regNum){
        int size = this.getParkingLotSize();
        if(size == 0) return notFound;
        return IntStream.range(0, size)
                .filter(index -> !this.parkingLot.get(index).isEmpty() && regNum.equals(this.parkingLot.get(index).getVehicleParked().getRegistrationNumber()))
                .map(i -> i+1)
                .mapToObj(String::valueOf)
                .reduce((accumulator, x) -> accumulator + ", " + x)
                .orElse(notFound);
    }

    public String getStatus(String format, String[] header){
        int size = this.getParkingLotSize();
        String heading = String.format(format, header[0], header[1], header[2]);
        if(size == 0) return heading;

        return IntStream.range(0, size)
                .mapToObj(index -> {
                    if(!parkingLot.get(index).isEmpty())
                        return String.format(format, parkingLot.get(index).getParkingSlotId()+1,
                                parkingLot.get(index).getVehicleParked().getRegistrationNumber(),
                                parkingLot.get(index).getVehicleParked().getColor());
                    return "";
                }).filter(s -> !s.equals(""))
                .reduce(heading , (accumulator, status) -> accumulator + "\n" + status);
    }


}
