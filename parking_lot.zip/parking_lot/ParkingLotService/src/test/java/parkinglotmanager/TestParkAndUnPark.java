package parkinglotmanager;

import vehicle.Car;
import org.junit.Test;
import static org.junit.Assert.*;

public class TestParkAndUnPark {

    @Test
    public void testPark(){
        ParkingLotManager parkingLotManager = new ParkingLotManager();
        parkingLotManager.createParkingLot(5);
        String registrationNumber = "KA 02 G 3412";
        String color = "red";
        Car car = new Car(registrationNumber, color);
        int slot = parkingLotManager.park(car);

        assertEquals(0, slot);
    }

    @Test
    public void testParkWhenLotIsFull(){
        ParkingLotManager parkingLotManager = new ParkingLotManager();
        parkingLotManager.createParkingLot(1);
        Car car = new Car("KA 02 B 1234", "blue");
        parkingLotManager.park(car);

        String registrationNumber = "KA 02 G 3412";
        String color = "red";
        int slot = parkingLotManager.park(new Car(registrationNumber, color));
        assertEquals(-1, slot);
    }

    @Test
    public void testLeave(){
        int slots = 5;
        ParkingLotManager parkingLotManager = new ParkingLotManager();
        parkingLotManager.createParkingLot(slots);

        parkingLotManager.park(new Car("KA 02 A 1234", "blue"));

        assertTrue(parkingLotManager.leave(1));
        assertFalse(parkingLotManager.leave(4));
    }

}
