package command;

import org.junit.Test;
import parkinglotmanager.ParkingLotManager;
import vehicle.Car;

import static org.junit.Assert.assertEquals;

public class TestCommandSlotForRegNum {
    @Test(expected = IllegalArgumentException.class)
    public void testCommandSlotForRegNumArgumentException(){
        ParkingLotManager parkingLotManager = new ParkingLotManager();
        String[] arguments = {"slot_number_for_registration_number"};
        CommandSlotForRegNum commandSlotForRegNum = new CommandSlotForRegNum(parkingLotManager, arguments);
    }

    @Test
    public void testCommandSlotForRegNum(){
        ParkingLotManager parkingLotManager = new ParkingLotManager();
        parkingLotManager.createParkingLot(3);
        parkingLotManager.park(new Car("KA-12-C-1234", "blue"));
        parkingLotManager.park(new Car("KA-12-C-1235", "red"));
        String[] arguments = {"slot_number_for_registration_number", "KA-12-C-1234"};

        CommandSlotForRegNum commandSlotForRegNum = new CommandSlotForRegNum(parkingLotManager, arguments);
        assertEquals("1", commandSlotForRegNum.execute());
    }

    @Test
    public void testCommandSlotForRegNumNotFound(){
        ParkingLotManager parkingLotManager = new ParkingLotManager();
        parkingLotManager.createParkingLot(3);
        parkingLotManager.park(new Car("KA-12-C-1234", "blue"));
        String[] arguments = {"slot_number_for_registration_number", "KA-12-C-1235"};

        CommandSlotForRegNum commandSlotForRegNum = new CommandSlotForRegNum(parkingLotManager, arguments);
        assertEquals("Not found", commandSlotForRegNum.execute());
    }

}
