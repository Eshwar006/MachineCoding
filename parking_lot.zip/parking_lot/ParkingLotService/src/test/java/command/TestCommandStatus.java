package command;

import org.junit.Test;
import parkinglotmanager.ParkingLotManager;
import vehicle.Car;

import static org.junit.Assert.assertEquals;

public class TestCommandStatus {

    @Test(expected = IllegalArgumentException.class)
    public void testCommandStatusArgumentException(){
        ParkingLotManager parkingLotManager = new ParkingLotManager();
        String[] arguments = {"status", "1"};
        CommandStatus commandStatus = new CommandStatus(parkingLotManager, arguments);
    }

    @Test
    public void testCommandStatus(){
        ParkingLotManager parkingLotManager = new ParkingLotManager();
        parkingLotManager.createParkingLot(3);
        parkingLotManager.park(new Car("KA-12-C-1234", "blue"));
        parkingLotManager.park(new Car("KA-12-C-1235", "red"));
        String[] arguments = {"status"};

        CommandStatus commandStatus = new CommandStatus(parkingLotManager, arguments);
        String expected = "Slot No.    Registration No    Colour\n" +
                "1           KA-12-C-1234       blue\n" +
                "2           KA-12-C-1235       red";
        assertEquals(expected, commandStatus.execute());
    }

    @Test
    public void testCommandStatusWithNoCars(){
        ParkingLotManager parkingLotManager = new ParkingLotManager();
        parkingLotManager.createParkingLot(3);
        String[] arguments = {"status"};

        CommandStatus commandStatus = new CommandStatus(parkingLotManager, arguments);
        String expected = "Slot No.    Registration No    Colour";
        assertEquals(expected, commandStatus.execute());
    }
}
