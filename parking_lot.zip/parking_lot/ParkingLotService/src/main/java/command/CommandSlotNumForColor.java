package command;

import parkinglotmanager.ParkingLotManager;

public class CommandSlotNumForColor implements Command{
    private ParkingLotManager parkingLotManager;
    private String color;

    public CommandSlotNumForColor(ParkingLotManager parkingLotManager, String[] args){
        if (args.length != 2) throw new IllegalArgumentException("SlotNumForColorCommand");
        this.parkingLotManager = parkingLotManager;
        color = args[1];
    }


    @Override
    public String execute() {
        return parkingLotManager.getSlotWithColor(color);
    }
}
