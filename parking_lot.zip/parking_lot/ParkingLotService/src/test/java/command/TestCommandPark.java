package command;

import org.junit.Test;
import parkinglotmanager.ParkingLotManager;
import vehicle.Car;

import static org.junit.Assert.*;

public class TestCommandPark {

    @Test(expected = IllegalArgumentException.class)
    public void testCommandParkArgumentException(){
        ParkingLotManager parkingLotManager = new ParkingLotManager();
        String[] arguments = {"park", "KA-02-B-1234"};
        CommandPark commandPark = new CommandPark(parkingLotManager, arguments);
    }

    @Test
    public void testCommandPark(){
        ParkingLotManager parkingLotManager = new ParkingLotManager();
        parkingLotManager.createParkingLot(3);
        String[] arguments = {"park", "KA-12-C-1234", "blue"};
        CommandPark commandPark = new CommandPark(parkingLotManager, arguments);
        assertEquals("Allocated slot number: 1", commandPark.execute());
    }

    @Test
    public void testCommandParkFullSlot(){
        ParkingLotManager parkingLotManager = new ParkingLotManager();
        parkingLotManager.createParkingLot(1);
        parkingLotManager.park(new Car("KA-02-B-1234", "red"));
        String[] arguments = {"park", "KA-12-C-1234", "blue"};
        CommandPark commandPark = new CommandPark(parkingLotManager, arguments);
        assertEquals("Sorry, parking lot is full", commandPark.execute());
    }

}
