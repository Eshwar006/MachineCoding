package command;

import org.junit.Test;
import parkinglotmanager.ParkingLotManager;
import vehicle.Car;

import static org.junit.Assert.assertEquals;

public class TestCommandRegNumForColor {

    @Test(expected = IllegalArgumentException.class)
    public void testCommandRegNumForColorArgumentException(){
        ParkingLotManager parkingLotManager = new ParkingLotManager();
        String[] arguments = {"registration_numbers_for_cars_with_colour"};
        CommandRegNumForColor commandRegNumForColor = new CommandRegNumForColor(parkingLotManager, arguments);
    }

    @Test
    public void testCommandRegNumForColor(){
        ParkingLotManager parkingLotManager = new ParkingLotManager();
        parkingLotManager.createParkingLot(3);
        parkingLotManager.park(new Car("KA-12-C-1234", "blue"));
        parkingLotManager.park(new Car("KA-12-C-1235", "red"));
        String[] arguments = {"registration_numbers_for_cars_with_colour", "red"};
        CommandRegNumForColor commandRegNumForColor = new CommandRegNumForColor(parkingLotManager, arguments);
        assertEquals("KA-12-C-1235", commandRegNumForColor.execute());
    }

    @Test
    public void testCommandRegNumForColor2(){
        ParkingLotManager parkingLotManager = new ParkingLotManager();
        parkingLotManager.createParkingLot(3);
        parkingLotManager.park(new Car("KA-12-C-1234", "red"));
        parkingLotManager.park(new Car("KA-12-C-1235", "red"));
        String[] arguments = {"registration_numbers_for_cars_with_colour", "red"};
        CommandRegNumForColor commandRegNumForColor = new CommandRegNumForColor(parkingLotManager, arguments);
        assertEquals("KA-12-C-1234, KA-12-C-1235", commandRegNumForColor.execute());
    }
}
