#How to run the code?
###Dependencies and execution
- Install maven based on your operating system using [this](https://maven.apache.org/install.html)</br>
- Under parking_lot folder run the following commands:
    > $ bin/setup # adds dependencies and installation <br/>

    > $ bin/parking_lot input.txt # input.txt is input file. not sending an argument runs the code in interactive mode <br/>

###What is bin?
- (bin/setup) contains maven install dependencies

    > $ mvn -f /path/to/pom.xml clean install # replace by path to directory which contains pom.xml

- (bin/parking_lot)contains details of running the jar 
    
    > $ java -cp $DIR/../ParkingLotService/target/parking-lot-1.0-SNAPSHOT.jar App $1  # $1 - file absolutepath or none(interactive)
