package parkinglotmanager;

import vehicle.Car;
import org.junit.Before;
import org.junit.Test;
import static org.junit.Assert.*;

public class TestStatus {
    private ParkingLotManager parkingLotManager = new ParkingLotManager();
    private static String printFormat = "%-12s%-19s%s";
    private static String[] header = {"Slot No.", "Registration No", "Colour"};

    @Before
    public void setup(){
        parkingLotManager.createParkingLot(6);
        parkingLotManager.park(new Car("KA-01-HH-1234", "white"));
        parkingLotManager.park(new Car("KA-01-HH-9999", "blue"));
        parkingLotManager.park(new Car("KA-02-BD-9876", "red"));
    }

    @Test
    public void testStatus(){
        String expected = "Slot No.    Registration No    Colour\n" +
                "1           KA-01-HH-1234      white\n" +
                "2           KA-01-HH-9999      blue\n" +
                "3           KA-02-BD-9876      red";
        assertEquals(expected, parkingLotManager.getStatus(printFormat, header));
    }

    @Test
    public void testEmptyStatus(){
        String expected = "Slot No.    Registration No    Colour";
        parkingLotManager.leave(1);
        parkingLotManager.leave(2);
        parkingLotManager.leave(3);
        assertEquals(expected, parkingLotManager.getStatus(printFormat, header));
    }


}
