import command.Command;
import parkinglotmanager.ParkingLotManager;

import java.io.*;
import java.lang.reflect.Constructor;
import java.util.HashMap;
import java.util.Map;
import command.*;

public class CommandController {

    private static Map<String, Class<? extends Command>> textToCommandMap;
    static {
        textToCommandMap = new HashMap<>();
        textToCommandMap.put("create_parking_lot", CommandCreateLot.class);
        textToCommandMap.put("park", CommandPark.class);
        textToCommandMap.put("leave", CommandLeave.class);
        textToCommandMap.put("status", CommandStatus.class);
        textToCommandMap.put("registration_numbers_for_cars_with_colour", CommandRegNumForColor.class);
        textToCommandMap.put("slot_numbers_for_cars_with_colour", CommandSlotNumForColor.class);
        textToCommandMap.put("slot_number_for_registration_number", CommandSlotForRegNum.class);
    }

    static Command getCommand(ParkingLotManager parkingLotManager, String completeCommand){
        String[] s = completeCommand.split(" ");
        try{
            Constructor<?> konstructor = textToCommandMap.get(s[0]).getConstructor(ParkingLotManager.class, String[].class);
            return (Command)konstructor.newInstance(parkingLotManager, s);
        } catch (Exception e){
            System.out.println("No Such Method");
        }
        return null;
    }

    static void processCommands(String[] args) throws IOException {
        BufferedReader buffer;
        if(args.length == 0){
            buffer = new BufferedReader(new InputStreamReader(System.in));
        } else {
            FileReader fileReader = new FileReader(args[0]);
            buffer = new BufferedReader(fileReader);
        }

        String line;
        ParkingLotManager parkingLotManager = new ParkingLotManager();

        while( (line=buffer.readLine())!=null){
            if(line.equals("exit")){
                System.out.println("Thank You for using ParkingLotService");
                return;
            }
            Command command = getCommand(parkingLotManager, line);
            if(command != null){
                String result = command.execute();
                if(result.length() != 0)
                    System.out.println(result);
            }

        }

    }
}
