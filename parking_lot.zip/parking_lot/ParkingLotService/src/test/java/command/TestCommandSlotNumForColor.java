package command;

import org.junit.Test;
import parkinglotmanager.ParkingLotManager;
import vehicle.Car;

import static org.junit.Assert.assertEquals;

public class TestCommandSlotNumForColor {

    @Test(expected = IllegalArgumentException.class)
    public void testCommandSlotNumForColorArgumentException(){
        ParkingLotManager parkingLotManager = new ParkingLotManager();
        String[] arguments = {"slot_numbers_for_cars_with_colour"};
        CommandSlotForRegNum commandSlotForRegNum = new CommandSlotForRegNum(parkingLotManager, arguments);
    }

    @Test
    public void testCommandSlotNumForColor(){
        ParkingLotManager parkingLotManager = new ParkingLotManager();
        parkingLotManager.createParkingLot(3);
        parkingLotManager.park(new Car("KA-12-C-1234", "blue"));
        parkingLotManager.park(new Car("KA-12-C-1235", "red"));
        String[] arguments = {"slot_numbers_for_cars_with_colour", "red"};

        CommandSlotNumForColor commandSlotNumForColor = new CommandSlotNumForColor(parkingLotManager, arguments);
        assertEquals("2", commandSlotNumForColor.execute());
    }

    @Test
    public void testCommandSlotNumForColorWithMultipleSlots(){
        ParkingLotManager parkingLotManager = new ParkingLotManager();
        parkingLotManager.createParkingLot(3);
        parkingLotManager.park(new Car("KA-12-C-1234", "red"));
        parkingLotManager.park(new Car("KA-12-C-1235", "red"));
        String[] arguments = {"slot_numbers_for_cars_with_colour", "red"};

        CommandSlotNumForColor commandSlotNumForColor = new CommandSlotNumForColor(parkingLotManager, arguments);
        assertEquals("1, 2", commandSlotNumForColor.execute());
    }

    @Test
    public void testCommandSlotNumForColorNotFound(){
        ParkingLotManager parkingLotManager = new ParkingLotManager();
        parkingLotManager.createParkingLot(3);
        parkingLotManager.park(new Car("KA-12-C-1234", "blue"));
        String[] arguments = {"slot_numbers_for_cars_with_colour", "red"};

        CommandSlotForRegNum commandSlotForRegNum = new CommandSlotForRegNum(parkingLotManager, arguments);
        assertEquals("Not found", commandSlotForRegNum.execute());
    }
}
